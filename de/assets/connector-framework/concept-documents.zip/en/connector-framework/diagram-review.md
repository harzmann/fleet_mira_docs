# Diagram review

The supplied illustration explains the package idea well, but sometimes conflates **user interaction**, **process communication** and **database access**. This page defines the connections and records the changes in the web edition dated 17 September 2026.

## Ambiguities identified

| Original element | Problem | Clarification |
|---|---|---|
| Double arrows between client, Core, worker and package | Direction and content are unspecified | Name action, request, job and result separately |
| Violet branches to several external systems | May appear to connect external systems to each other or arbitrary packages | Each connection belongs to one approved backend adapter |
| Violet connection to PostgreSQL | May suggest direct connector access to Core tables | Mira writes pass through gateway, Domain Services and Repositories |
| Orange connection to `custom_kunde` | Legend calls it external data although the target is inside PostgreSQL | Separate internal package data from external systems; remove the misleading connection |
| “Expansion Package Runtime” | Appears to show the whole package, including UI, as a separate process | Only the backend is isolated; the UI Extension runs in the Mira Client |
| Core within “Server / Infrastructure” | May imply a mandatory new server service | Treat Core as a logical shared service layer |
| “Update & Rollback” | Suggests recovery is always simple | Recovery depends on schema compatibility or a verified restore |
| “No Core changes, full updatability” | Absolute promise despite missing extension points | Implement extension points and test each version combination |

## Authoritative data-flow diagrams

The Mermaid diagrams are the precise technical companion to the simplified raster illustration. Each arrow has a named source, target and meaning. Concurrency and network boundaries must not be inferred beyond what the text states.

In the raster illustration, the result hand-off appears in a separate note: **Connector → Worker → Mira Services**. Return paths therefore do not cross database arrows. Actual business updates pass through the Integration Gateway.

```mermaid
sequenceDiagram
    participant UI as Mira UI
    participant S as Mira Services
    participant Q as Job storage
    participant W as FleetMiraWorker
    participant C as Backend Connector
    participant E as External system
    UI->>S: Action
    S->>Q: Store authorised request
    W->>Q: Claim job with lease
    Q-->>W: Job data
    W->>C: Job
    C->>E: API or agreed SQL
    E-->>C: Response
    C-->>W: Result or DTO
    W->>S: Validate and apply result
    S->>Q: Store processing state
    UI->>S: Request status
    S-->>UI: Result or review case
```

```mermaid
flowchart TB
    G["Mira Services<br/>Integration Gateway and Domain Services"]
    R["Registered Repositories"]
    C[("Mira Core data")]
    F[("Framework data<br/>Jobs, mappings, status")]
    P[("Approved package data")]
    G --> R
    R -->|"Business data"| C
    R -->|"Technical state"| F
    R -->|"Package contract"| P
```

The Backend Connector has **no** direct access to these Mira databases in this model. Direct SQL against an **external database** is a different, explicitly agreed adapter path. A connection to the previous fleet system is not planned because FLEET Mira replaces it.

## Illustration versions

### Revised illustration

![Revised English concept illustration](../assets/connector-framework/framework-overview.png)

System examples have been generalised to **ERP/Accounting**, **External system**, **Telematics** and **Other APIs**. The older original is not shown as a valid architecture on the website because it still includes a legacy-system connection that is no longer planned.

Editing used the built-in image tool. The [final edit instructions](../assets/connector-framework/image-edit-prompt.txt) are archived alongside the image. The diagram text and handbook define the limits of the illustration; it is not evidence of an implemented feature.
