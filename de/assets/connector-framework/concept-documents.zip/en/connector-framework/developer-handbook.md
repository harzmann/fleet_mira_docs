# Developer handbook

This document describes the target architecture of the **FLEET Mira Expansion Package Framework**. It is a baseline for implementation planning, interface contracts and acceptance testing. A package should connect external systems and customer-specific workflows without creating a customer-specific fork of the Mira product.

!!! info "Design status"
    Web edition **1.0, 17 September 2026**. Classes, manifests, tables and permissions described here are proposed contracts. Naming them does not imply that they are already implemented. Existing services should be reused, with missing extension points added deliberately.

## Architecture decisions

| Area | Decision |
|---|---|
| Product foundation | Shared codebase; Custom is an extension and service offering, not a separate Core fork |
| User interface | PySide6 extensions within Mira navigation |
| Background processing | One shared handler in `WorkerRuntime`; Enterprise hosts it in `FleetMiraWorker` |
| Connectors | Versioned isolated processes controlled by the worker; initially no additional Windows service |
| Mira business access | Integration Gateway, Domain Services and Repositories |
| External access | Only approved package API, file or SQL adapters |
| Storage | Separate logical ownership of Core, framework and package data; no vendor-specific Core fields |
| Cross-cutting services | Reuse existing jobs, permissions, audit and secret management |

## Existing components and new extension points

Existing reference points include `worker_runtime.py`, `worker_coordination.py`, `database_runtime.py`, `user_management.py`, `global_audit.py`, `administration_ui.py` and `ui_jobs.py`. Existing telematics adapters provide operational and integration examples. Their current implementation is not yet a generic Expansion Framework.

New work includes validated package registration, a manifest contract, a connector process manager, a gateway interface and defined UI extension points. A competing second queue, role or audit system is not intended. Existing import and retry mechanisms must be checked for their actual guarantees before being reused.

## Logical layers and process boundaries

```mermaid
flowchart TB
    subgraph Client["Enterprise Client"]
        UI["Core UI and Package UI"]
        S["Mira Services<br/>Permission check and job submission"]
        UI -->|"User action"| S
    end
    subgraph Server["Server and worker"]
        Q[("Framework jobs and status")]
        W["FleetMiraWorker<br/>WorkerRuntime and Expansion Manager"]
        G["Integration Gateway<br/>Domain Services and Repositories"]
        D[("Mira Core and package data")]
        Q -->|"Lease and job"| W
        W -->|"Validated result"| G
        G -->|"Transaction"| D
        W -->|"Progress and result status"| Q
    end
    subgraph Package["Separate connector process"]
        C["Backend Connector<br/>Adapter and mapping"]
    end
    E["External system"]
    S -->|"Store authorised job"| Q
    Q -->|"Read status"| S
    W -->|"Job through versioned protocol"| C
    C -->|"Result or DTO"| W
    C -->|"API or approved SQL"| E
    E -->|"Response"| C
```

**Core** denotes shared libraries and business services. It does not imply an additional central HTTP server. The Enterprise Client may submit jobs to PostgreSQL through existing Mira repositories. Central background effects run exclusively in the worker. The UI receives no external-system credentials.

The UI Extension runs in the client process; only the Backend Connector runs outside the worker process. Process isolation alone is not a security sandbox. A signed, approved package is still trusted executable code and requires a restricted operating account.

## Expansion Package structure

```text
expansion-example/
  manifest.json
  backend/          Connector, transport, mapping, DTOs
  ui/               Navigation, settings, mappings, status
  database/         Versioned package-data migrations
  workflows/        Job definitions and business rules
  permissions/      Permission names and translations
  reports/          Optional reports
  schemas/          JSON schemas and examples
  tests/            Contract, mapping and integration tests
```

A package includes only the components it needs. A customer package may depend on a standard package and add rules or screens. Customer rules are not embedded as special cases in the standard connector.

## Manifest and registration

The following manifest is a proposal, not an installable format currently supported by the product:

```json
{
  "id": "example-sap",
  "version": "0.1.0",
  "vendor": "eh-systemhaus e.K.",
  "expansion_api": "1",
  "core_compatibility": ">=1.0,<2.0",
  "backend": {"entrypoint": "backend/connector.exe", "protocol": "1"},
  "ui": {"entrypoint": "ui.extension:register"},
  "capabilities": ["vehicle.pull", "invoice.push"],
  "permissions": ["example.view", "example.configure", "example.execute"],
  "database": {"namespace": "integration_example", "version": 1},
  "dependencies": []
}
```

Version ranges are examples. The implementation must define binding ranges for Core, SDK, protocol, UI and schema. Installation validates package ID, origin, signature, checksums, dependencies and paths. Paths must remain within the approved package directory; manifest values must not become arbitrarily composed shell commands.

The registry records installed and active versions, compatibility, schema version, capabilities and error state. Installation, activation and permission are distinct states. An incompatible package remains visible but is not loaded. Each package has one active version per defined installation or tenant.

## UI integration

A UI Extension registers navigation entries, workspace factories and actions through a bounded host interface. The host supplies context, authorisation, translation, regional formatting and service access. A possible interface includes `navigation_items()`, `create_workspace(page_id, context)` and `register_actions()`.

Integration follows the existing administration and workspace patterns:

- Non-selectable navigation group, selectable workspace and at most one local subtab level.
- Search/filter area, shared action bar, data grid and status area for lists.
- Dedicated record-detail work tabs for substantial editing; reopening focuses the same record.
- Stable technical widget IDs and an empty work-tab area at session start.
- Permission checks in both UI **and** called service; hidden buttons do not authorise an action.
- Network and database work outside the Qt main thread.
- All visible text in the 23 supported application languages; documentation in at least German and English.

For Enterprise/Custom, navigation could offer “Administration → Integrations → SAP”. Configuration, mappings, jobs and logs become suitable workspaces or a single local subtab level. An additional deep navigation hierarchy is unnecessary.

## Worker and process protocol

The Expansion Manager handles discovery, compatibility, activation and state. A subordinate connector process host launches approved programs, limits duration and output, and terminates hung processes. Scheduling, retry and job ownership remain in the shared worker runtime.

Version 1 should evaluate a versioned, framed JSON/NDJSON protocol over standard input/output. `stdout` contains protocol messages only; bounded, sanitised diagnostics use a separate channel. Messages identify protocol version, package, action, job and correlation. Larger datasets are transferred in bounded batches. Spool files are permitted only when needed, with ACLs, size limits, checksums and expiry.

```json
{
  "protocol": 1,
  "job_id": "example-job",
  "correlation_id": "example-correlation",
  "package": "example-sap",
  "action": "vehicle.pull",
  "checkpoint": null
}
```

Results distinguish `succeeded`, `retryable_error`, `validation_error` and `outcome_unknown`. Errors contain stable codes and sanitised messages, never credentials. Subprocess termination, incomplete output or a lost connection after a possible creation must not be treated as a definitely unsuccessful write.

## Data contracts and Integration Gateway

Adapters translate external formats into small versioned DTOs, such as vehicle, person, cost centre or approved invoice line. Business identity, source tenant, external ID, date semantics, required fields and deletion semantics are explicit. Missing, empty and `null` are not automatically equivalent.

```mermaid
flowchart TB
    A["External response"] --> B["Connector mapping"]
    B --> C["Versioned DTO"]
    C --> D["Integration Gateway"]
    D --> E["Validation and permission"]
    E --> F["Domain Service"]
    F --> G["Repository and transaction"]
    G --> H["Mira business data and audit"]
```

**Connectors never write directly to Mira Core business tables.** The gateway also defines which objects a package may read. A SQL connector for an external system is different: it may execute explicitly agreed, parameterised SQL operations there.

## Storage and ownership

| Area | Owner | Examples |
|---|---|---|
| Mira Core | Mira repositories and business logic | Vehicles, people, costs and documents |
| Framework | Host repositories | Package versions, technical mappings, checkpoints, jobs and run status |
| Package data | Registered package repositories and migrations | Required account or workflow mappings |
| External system | Explicit backend adapter | API requests or approved SQL |

For Enterprise, logical separation into `public`, `integration`, `integration_<package>` or `custom_<customer>` is proposed. **These are proposed schema names.** Actual migrations must fit the existing database abstraction. New shared repository functions must introduce neither PostgreSQL-specific branches in business code nor direct `sqlite3` connections. Affected shared functions must produce the same business result on SQLite and PostgreSQL.

By default the host manages package data through registered repositories too. Direct database access by an isolated connector is unnecessary and is not generally authorised. Required mappings are supplied to the job through controlled interfaces.

Technical object mappings are unique at least by environment, installation/tenant, external account, package, object type and external ID. A complete payload mirror is not an automatic framework feature. Retention, personal data and required comparison states are defined per package.

## Outbound processing

```mermaid
sequenceDiagram
    participant U as User
    participant M as Mira Service
    participant DB as Mira Database
    participant W as FleetMiraWorker
    participant C as Connector
    participant X as External system
    U->>M: Approve transaction
    M->>DB: Business change and outbox in one transaction
    DB-->>M: Commit
    W->>DB: Claim job with lease
    W->>C: Job and idempotency key
    C->>X: External operation
    X-->>C: Confirmation and external ID
    C-->>W: Result
    W->>DB: Confirm mapping, status and audit
```

HTTP requests occur outside the business transaction. The worker must expect at-least-once delivery. If the target supports idempotency keys, the same key is reused for the same business job. Otherwise the outcome is reconciled before retry. An uncertain creation remains held for review. A local commit and an external HTTP effect are not one atomic transaction.

## Inbound processing and conflicts

The connector reads all relevant pages, validates the contract and returns DTOs. The host resolves technical identities and applies approved fields in a transaction. A checkpoint advances only after a complete fetch and the defined safe processing state. Fetch completeness and successful business application are reported separately.

Delta filters are permitted only if they include later updates to old records. Otherwise periodic full reconciliation is required. Registration plate, date or description alone do not justify an automatic merge. An existing external ID and explicit mapping take precedence; ambiguous matches enter the review queue.

System ownership is defined per field. Locally changed imported fields are compared with the last confirmed write state. A conflict must remain visible rather than disappear through silent overwriting.

## Permissions, secrets and audit

Package permissions join existing role management, for example view, configure, map, execute and approve. The worker rechecks package activation, action and job origin. External connections, secrets and target credentials remain on the worker side; client configurations contain references only.

Audit records relate the user or system actor, package version, action, object, result and correlation ID. Tokens, passwords and complete personal payloads do not belong in technical logs. Package installation, migration, permission changes and manual conflict decisions are also traceable.

A central status view shows the last successful run, oldest open job, pending reviews and data freshness. Retries use bounded backoff and `Retry-After` where applicable. Data errors and missing business mappings require correction rather than endless automatic retry.

## SAP package example

A SAP package may include connection setup, account/cost-centre mappings, approval, export status and reports. Valid rules map a cost type to company code, account, tax code and, where applicable, profit centre. This is a business mapping with validity dates and review status, not uncontrolled text conversion.

```mermaid
flowchart TB
    A["Review invoice"] --> B["Assign vehicle and cost type"]
    B --> C["Validate SAP coding"]
    C --> D["Approve"]
    D --> E["Outbox"]
    E --> F["Worker and SAP Connector"]
    F --> G["SAP confirmation"]
```

SAP illustrates package architecture here; it does not imply an already available connector or a particular SAP API.

## External systems and telematics

FLEET Mira is the successor product. The framework extends Mira and connects external business systems; ongoing synchronisation with the previous fleet system is not planned. Any required one-time migration belongs to a separate migration project.

```mermaid
flowchart TB
    UI["Mira Package UI"] -->|"Validated request"| Q["Mira job storage"]
    Q -->|"Lease and job"| W["FleetMiraWorker"]
    W -->|"Job"| P["Backend Connector"]
    P -->|"Approved API / SQL"| E["External system or telematics"]
    E -->|"Response"| P
    P -->|"DTO and technical status"| W
    W -->|"Validate and apply"| G["Mira Integration Gateway"]
    G -->|"Business logic and repository"| D[("Mira business data")]
```

Each concrete package needs a confirmed interface contract covering authentication, required fields, date semantics, pagination and update behaviour. Choosing API, file or direct SQL concerns the external target system, not a bypass into Mira Core tables.

The following rules apply:

- Reconcile only explicitly agreed, semantically matching fields. Do not automatically add vendor-specific information as new Core fields.
- New records are possible when identity, required fields and system ownership are confirmed.
- Keep technical mappings, checksums and errors separate from business data. Do not retain mirrored payloads without a justified package contract.
- Define data ownership and local editing per field. External statuses must not trigger local completion without agreed rules.
- Configure schedules and data freshness per system. Without a reliable change filter, use complete reconciliation to capture updates to older records too.
- External writes require clear retry and reconciliation rules. Resolve uncertain creation outcomes before writing again.
- A SQL adapter uses fixed approved table/column names, bound parameters, restricted permissions and local transactions.
- HTTP effects, external SQL transactions and Mira transactions are not automatically atomic. Failure boundaries and restart recovery belong to the package contract.

Implementation uses existing Mira host facilities for operation, scheduling, jobs and monitoring. An additional independent scheduler or Windows service is not planned.

## Versioning, installation and recovery

Core, Expansion API, package, UI and schema have separate versions. A package is validated and installed into a versioned directory, then migrated and activated under control. Running jobs finish or stop at a confirmed checkpoint before switching. New jobs start only with a consistent backend/UI/schema combination.

```mermaid
flowchart TB
    A["Install package"] --> B["Check signature and compatibility"]
    B --> C["Check backup and migration"]
    C --> D["Run migration"]
    D --> E["Activate and smoke-test"]
    E --> F["Monitor"]
    F --> G["Prepare update"]
    G --> B
    E -->|"Failure"| R["Deactivate and apply verified restore"]
```

Replacing an executable is not sufficient rollback after an incompatible data migration. Recovery requires backward-compatible schema or a verified backup/restore procedure. Program files are read-only; mutable configuration and state remain separate. UI bundles load only from approved packages, not arbitrary user-writable Python paths.

## Repository strategy and CI/CD

Mira Core retains host integration and shared business logic. A separate expansion repository may group SDK, protocol, schemas, testkit and standard packages. Customer packages may have private repositories. Separation is useful only when versioning and contract checks are reproducible; this document does not create those repositories.

The pipeline checks manifests, dependencies, package boundaries, unit/contract tests, migrations, UI compatibility and absence of secrets. It builds versioned artefacts, produces checksums, signs Windows components for release and tests installation, update and recovery. A release references tested Core, SDK, schema and package versions.

## Implementation and acceptance

1. Review the existing architecture and binding package contracts; define the Enterprise pilot and field ownership.
2. Implement minimal registration and package validation; integrate a test package without external writes.
3. Add a shared worker handler, process protocol, leases and error classes.
4. Implement the gateway and technical mappings with transaction/conflict checks.
5. Integrate the UI Extension with existing navigation, permissions and translations.
6. Integrate the first external-system package using a confirmed contract and isolated test environment.
7. Demonstrate pilot operation, restart recovery, update and restore before production approval.

| Acceptance test | Expected result |
|---|---|
| Incompatible or modified package | No activation; understandable error status |
| Missing permission | Action rejected on the service side too |
| Repeated job | No additional external or local creation |
| Two workers | Exclusive lease; a former owner cannot continue writing |
| Crash after possible commit | Uncertain outcome remains held and is reconciled |
| Local field change | Visible conflict; no silent loss |
| API limit or expired token | Bounded recovery without secrets in logs |
| Version change | Tested combination; traceable migration and restore |
| UI and languages | Shared navigation rules, stable IDs, complete translations |
| Shared database function | Same business result on SQLite and PostgreSQL |

This document extends the documentation, not the application's delivered capabilities. General architecture rules remain binding during implementation.
