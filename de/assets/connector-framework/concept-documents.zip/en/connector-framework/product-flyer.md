---
hide:
  - toc
---

# Product flyer

**FLEET Mira Custom connects fleet processes with business IT.** Expansion Packages group interfaces, integrated operation and customer-specific rules on a shared product foundation.

!!! info "Target concept from September 2026"
    The illustration describes the proposed architecture. Packages and interfaces are implemented and approved per project.

![Revised FLEET Mira Expansion Package Framework overview separating jobs, results and database access](../assets/connector-framework/framework-overview.png)

[Open full-resolution illustration](../assets/connector-framework/framework-overview.png){ .md-button }

| Operate in Mira | Process centrally | Connect systems |
|---|---|---|
| Settings, mappings, review and status in the familiar workspace | FleetMiraWorker controls jobs, retries and monitoring | Package adapters connect ERP/accounting, external business systems and telematics |

**One package with the components required:** Backend Connector · UI Extension · Workflow and Mapping · Permissions · separate package data and reports where needed.

**Project path:** Assessment → agreed concept → implementation → pilot → operational approval. Licensing, project services and maintenance are agreed separately.

**Product role:** FLEET Mira is the successor product. A permanent interface to the previous fleet system is not planned.

**Architecture rule:** External connectors change Mira Core data only through validated Mira services. Direct SQL may form part of an explicitly agreed adapter to an external system.

[Customer concept](customer-concept.md) · [Developer handbook](developer-handbook.md) · [Arrows and corrections explained](diagram-review.md)
