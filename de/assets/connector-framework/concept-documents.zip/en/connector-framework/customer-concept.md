# Customer concept

**FLEET Mira Custom** is intended to extend the shared FLEET Mira application with the interfaces and workflows a business needs. Related functions are delivered as an **Expansion Package**. Operation, permissions and monitoring remain integrated into Mira.

!!! info "Concept status"
    This description explains the proposed extension architecture as of September 2026. Availability, specific integrations, scope and dates are confirmed per project. The framework is not yet a generally released product feature.

## What an Expansion Package contains

A package may contain a connection to another system, suitable screens, mapping rules and automated workflows. Only required components are implemented. A SAP integration, for example, needs different settings from a vehicle synchronisation package.

| Component | Meaning in daily work |
|---|---|
| Connector | Sends agreed data to the connected system and reads its responses |
| Integrated interface | Displays settings, review cases and progress directly in Mira |
| Rules and mappings | Unambiguously relates vehicles, cost centres or ledger accounts |
| Permissions | Defines who may view, change, start or approve |
| Additional storage | Keeps required package information separate from the standard data model |
| Reports | Makes results and pending work traceable |

## How the exchange works

```mermaid
flowchart TB
    A["Employee reviews or starts"] --> B["Mira stores the job"]
    B --> C["Central worker processes"]
    C --> D["Package connects external system"]
    D --> E["Response is validated"]
    E --> F["Result or review case in Mira"]
```

Transfers run in the background. Employees do not need to operate an additional connector application. Business approvals remain where required. Technical failures result in controlled retry or a visible review case.

## Example customer projects

**Invoice hand-off to SAP:** An invoice is reviewed in Mira, assigned to a vehicle and cost type, and approved. The agreed SAP coding is validated. The package then transfers the job and records the response. Transfer does not automatically mean that an invoice has been paid.

**External system:** An agreed package exchanges approved data with an external business system. Field mapping, the leading system and permitted changes are explicitly defined. Responses requiring review appear in Mira for processing.

**Telematics:** A package may exchange vehicle mappings and approved operational data with a telematics service. Scope, timestamps and polling intervals follow the confirmed contract of the selected service.

**Customer-specific rules:** Extra validation, approvals or reports may live in a dedicated customer package. A standard connector remains separate from customer-specific exceptions.

## Data responsibility

Before implementation, each data area has an agreed leading system, field mapping and conflict procedure. New records and updates need unambiguous identities. Ambiguous matches are reviewed rather than silently merged based on similar names or registration plates.

FLEET Mira is introduced as the successor product. Ongoing coupling with the previous fleet system is not planned. Any necessary one-time migration of existing data must be separately designed, validated and accepted.

Transfers contain explicitly agreed data only. Technical mappings, checksums and error records support reliable operation; a complete additional payload mirror is not created automatically.

## Operation and future development

External credentials remain on the execution server. Existing Mira roles and logs are intended to govern extensions too. Responsible users see successful runs, open jobs and errors and can make targeted corrections.

Packages and standard software are intended to evolve independently. Compatible versions are explicitly tested. Updates may need migrations and backup; returning to an older executable alone may be insufficient. These checks form part of the agreed operational procedure.

## Introduction in five steps

1. **Assessment:** Identify systems, data, access, responsible people and desired workflows.
2. **Target concept:** Agree field mappings, leading systems, permissions, failure cases and acceptance criteria.
3. **Implementation:** Configure the standard package and add required customer functions.
4. **Pilot:** Reconcile representative cases in a test environment and review the results.
5. **Approval:** Hand over operation, monitoring, backup and responsibilities.

## Services and quotation

FLEET Mira Custom is an Enterprise-based solution with separately agreed integration and development services. Licensing, analysis, implementation, migration, training and ongoing maintenance are separate quotation items. This concept establishes no binding prices, SAP certifications or guaranteed delivery dates.

The goal is a shared, maintainable product foundation with clearly bounded customer functions. The appropriate extension is chosen and accepted against the actual workflow.

[Visual product flyer](product-flyer.md) · [Developer handbook](developer-handbook.md)
