# Connector Framework

The **FLEET Mira Expansion Package Framework** is the target concept for customer-specific modules, integrations and workflows based on FLEET Mira. An Expansion Package groups the required connectors, integrated screens, mapping rules and permissions.

!!! info "Concept and development baseline"
    Status: **17 September 2026**. These pages describe a proposed extension architecture, not a released framework feature. The shared application core and worker runtime exist; package registration, the extension protocol and Integration Gateway still require implementation and acceptance testing.

## The three concept documents

| Document | Audience | Contents |
|---|---|---|
| [Developer handbook](developer-handbook.md) | Developers and integrators | Architecture, extension points, data contracts, workflows, security, testing and deployment with Mermaid diagrams |
| [Customer concept](customer-concept.md) | Customers and project owners | Benefits, components, example processes, introduction and scope |
| [Product flyer](product-flyer.md) | Initial discussions and overview | Compact visual summary of the concept |

[Diagram review and authoritative arrow semantics](diagram-review.md) explains the corrections to the supplied overview. Its directed diagrams clarify the simplified illustration.

[Download the web edition](../assets/connector-framework/concept-documents.zip){ .md-button }

The ZIP contains the German and English Markdown editions, illustrations and Mermaid source text. It does not contain the original Word files.

## Architecture at a glance

```mermaid
flowchart TB
    U["Mira Client<br/>Core UI and UI Extensions"] -->|"Action through Mira Services"| Q["Job storage"]
    Q -->|"Claim job"| W["FleetMiraWorker"]
    W -->|"Job"| C["Backend Connector<br/>isolated process"]
    C -->|"API or SQL"| E["External system"]
    E -->|"Response"| C
    C -->|"Result or DTO"| W
    W -->|"Validate and apply"| G["Integration Gateway<br/>Domain Services and Repositories"]
    G -->|"Validated changes"| D[("Mira business data")]
```

**Reading guide:** An arrow represents a named operation or data hand-off. The Core is a logical software layer, not an additional mandatory server service. External connectors do not write directly to Mira Core tables.

## About these documents

This web edition converts the available content of the August 2026 “FLEET Mira Custom” concept and the supplied illustration into version-controlled Markdown documents. The three original Word files were not available for this transfer; these pages are therefore an **edited web edition**, not unchanged DOCX originals. German and English are maintained together.

The revised architecture accounts for the existing shared product runtime. Basic and Pro retain SQLite with an in-process worker; Enterprise uses PostgreSQL and the separate `FleetMiraWorker`. The expansion concept starts with Enterprise/Custom; enabling other editions requires explicit classification and testing.

FLEET Mira is intended as the successor product. A permanent connection to the previous fleet system is outside the target architecture. Examples use general categories such as **External system**, **ERP/Accounting** and **Telematics**. Any required one-time data migration would be a separate project, not an ongoing connector.
