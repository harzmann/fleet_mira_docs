FLEET Mira Connector Framework
Edited web edition, 17 September 2026.
German and English Markdown with Mermaid and images. These are not the original Word files.
This is a target concept, not implemented framework functionality.
