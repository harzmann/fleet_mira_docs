# Produktbeschreibung

**FLEET Mira Custom** soll die gemeinsame FLEET-Mira-Anwendung um die Schnittstellen und Abläufe ergänzen, die ein Unternehmen benötigt. Dafür werden zusammengehörige Funktionen als **Expansion Package** bereitgestellt. Bedienung, Rechteverwaltung und Betriebsüberwachung bleiben in Mira eingebunden.

!!! info "Konzeptstand"
    Diese Beschreibung erläutert die geplante Erweiterungsarchitektur vom September 2026. Verfügbarkeit, konkrete Schnittstellen, Leistungsumfang und Termine werden pro Projekt bestätigt. Das Framework ist noch keine allgemein freigegebene Produktfunktion.

## Was ein Expansion Package enthält

Ein Paket kann eine Verbindung zu einem Fremdsystem, passende Eingabemasken, Zuordnungsregeln und automatisierte Abläufe enthalten. Nur benötigte Bestandteile werden umgesetzt. Eine SAP-Anbindung benötigt zum Beispiel andere Einstellungen als ein Fahrzeugdatenabgleich.

| Bestandteil | Bedeutung im Arbeitsalltag |
|---|---|
| Connector | Überträgt vereinbarte Daten zum angebundenen System und liest dessen Antworten |
| Integrierte Oberfläche | Zeigt Einstellungen, Prüffälle und Bearbeitungsstand direkt in Mira |
| Regeln und Zuordnungen | Ordnet beispielsweise Fahrzeuge, Kostenstellen oder Sachkonten eindeutig zu |
| Berechtigungen | Legt fest, wer sehen, ändern, starten oder freigeben darf |
| Ergänzende Datenhaltung | Speichert erforderliche Paketinformationen getrennt vom Standarddatenmodell |
| Auswertungen | Macht Ergebnisse und offene Aufgaben nachvollziehbar |

## Wie der Austausch funktioniert

```mermaid
flowchart TB
    A["Mitarbeiter prüft oder startet"] --> B["Mira speichert den Auftrag"]
    B --> C["Zentraler Worker bearbeitet"]
    C --> D["Paket verbindet das Fremdsystem"]
    D --> E["Antwort wird geprüft"]
    E --> F["Ergebnis oder Prüffall in Mira"]
```

Die Übertragung läuft im Hintergrund. Mitarbeiter müssen dafür keine zusätzliche Connector-Anwendung bedienen. Fachliche Freigaben bleiben dort erhalten, wo sie erforderlich sind. Ein technischer Fehler führt zu einer kontrollierten Wiederholung oder einem sichtbaren Prüffall.

## Beispiele für Kundenprojekte

**Rechnungsübergabe an SAP:** Eine Rechnung wird in Mira geprüft, einem Fahrzeug und einer Kostenart zugeordnet und freigegeben. Die vereinbarte SAP-Kontierung wird geprüft. Anschließend überträgt das Paket den Auftrag und dokumentiert die Rückmeldung. Eine Übertragung bedeutet nicht automatisch, dass eine Rechnung bereits bezahlt ist.

**Externes System:** Ein abgestimmtes Paket tauscht freigegebene Daten mit einem externen Fachsystem aus. Feldzuordnung, führendes System und zulässige Änderungen werden ausdrücklich festgelegt. Prüfpflichtige Rückmeldungen erscheinen in Mira zur Bearbeitung.

**Telematik:** Ein Paket kann Fahrzeugzuordnungen und freigegebene Betriebsdaten mit einem Telematikdienst austauschen. Datenumfang, Zeitbezug und Abrufintervalle richten sich nach dem bestätigten Vertrag des jeweiligen Dienstes.

**Kundenspezifische Regeln:** Zusätzliche Prüfungen, Freigaben oder Berichte können in einem eigenen Kundenpaket liegen. Ein Standardconnector bleibt dadurch von kundenspezifischen Sonderregeln getrennt.

## Verantwortung für Daten

Vor Projektbeginn wird je Datenbereich vereinbart, welches System führt, welche Felder übertragen werden und wie Konflikte behandelt werden. Neue Datensätze und Änderungen benötigen eindeutige Identitäten. Mehrdeutige Treffer werden geprüft, statt anhand ähnlicher Namen oder Kennzeichen still zusammengeführt zu werden.

FLEET Mira wird als Nachfolgeprodukt eingeführt. Eine laufende Kopplung mit dem bisherigen Fuhrparksystem ist nicht vorgesehen. Eine erforderliche einmalige Übernahme von Bestandsdaten muss separat geplant, geprüft und abgenommen werden.

Übertragen werden die ausdrücklich vereinbarten Daten. Technische Zuordnungen, Prüfsummen und Fehlerprotokolle dienen dem sicheren Betrieb; ein vollständiger zusätzlicher Nutzdatenspiegel entsteht nicht automatisch.

## Betrieb und Weiterentwicklung

Externe Zugangsdaten bleiben auf der ausführenden Serverseite. Vorhandene Mira-Rollen und Protokolle sollen auch die Erweiterungen steuern. Verantwortliche sehen erfolgreiche Läufe, offene Aufträge und Fehler und können die notwendigen Korrekturen gezielt durchführen.

Pakete und Standardsoftware sollen getrennt weiterentwickelt werden können. Dazu werden kompatible Versionen ausdrücklich geprüft. Updates können Migrationen und eine Datensicherung benötigen; eine Rückkehr auf eine alte Programmdatei allein reicht dann nicht aus. Diese Prüfungen sind Bestandteil des vereinbarten Betriebsverfahrens.

## Einführung in fünf Schritten

1. **Bestandsaufnahme:** Systeme, Daten, Zugänge, Verantwortliche und gewünschte Abläufe erfassen.
2. **Sollkonzept:** Feldzuordnung, führende Systeme, Rechte, Fehlerfälle und Abnahme gemeinsam festlegen.
3. **Umsetzung:** Standardpaket konfigurieren und notwendige Kundenfunktionen ergänzen.
4. **Pilot:** Repräsentative Fälle in einer Testumgebung abgleichen und Ergebnisse prüfen.
5. **Freigabe:** Betrieb, Überwachung, Sicherung und Verantwortlichkeiten übergeben.

## Leistung und Angebot

FLEET Mira Custom umfasst eine Enterprise-basierte Lösung mit gesondert vereinbarten Integrations- und Entwicklungsleistungen. Lizenzen, Analyse, Umsetzung, Migration, Schulung und laufende Pflege werden im Angebot getrennt beschrieben. Aus diesem Konzept ergeben sich keine verbindlichen Preise, SAP-Zertifizierungen oder garantierten Liefertermine.

Ziel ist eine gemeinsame, wartbare Produktbasis mit klar abgegrenzten Kundenfunktionen. Die passende Erweiterung wird anhand des tatsächlichen Prozesses ausgewählt und abgenommen.

[Zum grafischen Produktflyer](product-flyer.md) · [Zum Entwicklerhandbuch](developer-handbook.md)
