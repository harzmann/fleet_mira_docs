---
hide:
  - toc
---

# Produktflyer

**FLEET Mira Custom verbindet Fuhrparkprozesse mit der Unternehmens-IT.** Expansion Packages bündeln Schnittstellen, integrierte Bedienung und kundenspezifische Regeln auf einer gemeinsamen Produktbasis.

!!! info "Zielkonzept vom September 2026"
    Die Abbildung beschreibt die geplante Architektur. Pakete und Schnittstellen werden projektbezogen umgesetzt und freigegeben.

![Überarbeitete Übersicht des FLEET Mira Expansion Package Frameworks mit getrennten Aufträgen, Ergebnissen und Datenbankzugriffen](../assets/connector-framework/framework-overview.png)

[Grafik in voller Auflösung öffnen](../assets/connector-framework/framework-overview.png){ .md-button }

| In Mira bedienen | Zentral verarbeiten | Systeme anbinden |
|---|---|---|
| Einstellungen, Zuordnungen, Prüfungen und Status im vertrauten Arbeitsbereich | FleetMiraWorker steuert Aufträge, Wiederholung und Überwachung | Paketadapter verbinden ERP/Buchhaltung, externe Fachsysteme und Telematik |

**Ein Paket, passende Bestandteile:** Backend Connector · UI Extension · Workflow und Mapping · Berechtigungen · bei Bedarf getrennte Paketdaten und Berichte.

**Der Projektweg:** Analyse → abgestimmtes Konzept → Umsetzung → Pilot → Betriebsfreigabe. Lizenz, Projektleistungen und Pflege werden gesondert vereinbart.

**Produktrolle:** FLEET Mira ist das Nachfolgeprodukt. Eine dauerhafte Schnittstelle zum bisherigen Fuhrparksystem ist nicht vorgesehen.

**Architekturregel:** Externe Connectoren ändern Mira-Core-Daten ausschließlich über geprüfte Mira-Dienste. Direkte SQL-Anweisungen können Teil eines ausdrücklich vereinbarten Adapters zum externen System sein.

[Produktbeschreibung](customer-concept.md) · [Entwicklerhandbuch](developer-handbook.md) · [Pfeile und Korrekturen erläutert](diagram-review.md)
