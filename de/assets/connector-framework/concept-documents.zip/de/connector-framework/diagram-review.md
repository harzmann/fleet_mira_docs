# Grafikprüfung

Die bereitgestellte Grafik vermittelt die Paketidee gut, vermischt aber an einigen Stellen **Bedienung**, **Prozesskommunikation** und **Datenbankzugriffe**. Diese Seite legt die Bedeutung der Verbindungen fest und dokumentiert die Änderungen für die Web-Ausgabe vom 17.09.2026.

## Gefundene Unklarheiten

| Stelle im Original | Problem | Präzisierung |
|---|---|---|
| Doppelpfeile zwischen Client, Core, Worker und Package | Richtung und Inhalt der Übergabe bleiben offen | Aktion, Auftrag, Job und Ergebnis getrennt benennen |
| Violette Verzweigungen zu mehreren Fremdsystemen | Pfeile wirken wie eine Verbindung zwischen fremden Systemen oder beliebigen Paketen | Jede Verbindung gehört zu genau einem freigegebenen Backendadapter |
| Violette Verbindung zur PostgreSQL-Datenbank | Kann direkten Core-Datenbankzugriff durch Connectoren suggerieren | Mira-Schreibzugriffe führen über Gateway, Domain Services und Repositories |
| Orange Verbindung zum Schema `custom_kunde` | Legende nennt externe Daten, Ziel liegt jedoch innerhalb von PostgreSQL | Interne Paketdaten von externen Systemen trennen; missverständliche Verbindung entfernen |
| „Expansion Package Runtime“ | Scheint das gesamte Paket einschließlich UI als Prozess zu zeigen | Nur der Backend Connector läuft isoliert; die UI Extension läuft im Mira Client |
| Core innerhalb „Server / Infrastruktur“ | Kann einen neuen zwingenden Serverdienst nahelegen | Core als logische, gemeinsam verwendete Serviceschicht verstehen |
| „Update & Rollback“ | Suggeriert einen immer einfachen Rückweg | Rückkehr hängt von Schema-Kompatibilität oder geprüftem Restore ab |
| „Keine Core-Anpassungen, volle Updatefähigkeit“ | Absolute Zusage trotz fehlender Erweiterungspunkte | Erweiterungspunkte implementieren; jede Versionskombination prüfen |

## Verbindliche Datenflussdarstellung

Die Mermaid-Darstellungen sind die präzise technische Ergänzung zur vereinfachten Rastergrafik. Pfeile haben jeweils eine benannte Quelle, ein Ziel und eine Bedeutung. Gleichzeitigkeit oder Netzwerkgrenzen dürfen daraus nicht zusätzlich abgeleitet werden.

In der Rastergrafik steht die Ergebnisrückgabe in einem eigenen Hinweiskasten: **Connector → Worker → Mira Services**. Dadurch kreuzen Rückgabeverbindungen keine Datenbankpfeile. Die tatsächliche Übernahme erfolgt über das Integration Gateway.

```mermaid
sequenceDiagram
    participant UI as Mira UI
    participant S as Mira Services
    participant Q as Auftragsablage
    participant W as FleetMiraWorker
    participant C as Backend Connector
    participant E as Externes System
    UI->>S: Aktion
    S->>Q: Berechtigten Auftrag speichern
    W->>Q: Auftrag mit Lease übernehmen
    Q-->>W: Jobdaten
    W->>C: Job
    C->>E: API oder vereinbartes SQL
    E-->>C: Antwort
    C-->>W: Ergebnis oder DTO
    W->>S: Ergebnis validieren und übernehmen
    S->>Q: Verarbeitungsstand speichern
    UI->>S: Status abfragen
    S-->>UI: Ergebnis oder Prüffall
```

```mermaid
flowchart TB
    G["Mira Services<br/>Integration Gateway und Domain Services"]
    R["Registrierte Repositories"]
    C[("Mira-Core-Daten")]
    F[("Framework-Daten<br/>Jobs, Zuordnungen, Status")]
    P[("Freigegebene Paketdaten")]
    G --> R
    R -->|"Fachdaten"| C
    R -->|"Technischer Zustand"| F
    R -->|"Paketvertrag"| P
```

Der Backend Connector besitzt in dieser Darstellung **keinen** direkten Zugriff auf diese Mira-Datenbanken. Ein direkter SQL-Zugriff auf eine **externe Datenbank** ist ein anderer, ausdrücklich vereinbarter Adapterweg. Eine Anbindung an das bisherige Fuhrparksystem ist nicht vorgesehen, da FLEET Mira dessen Nachfolge übernimmt.

## Bildfassungen

### Überarbeitete Darstellung

![Überarbeitete deutsche Konzeptgrafik](../assets/connector-framework/framework-overview.png)

Die Systembeispiele wurden auf **ERP/Buchhaltung**, **Externes System**, **Telematik** und **Weitere APIs** verallgemeinert. Die ältere Vorlage wird auf der Website nicht als gültige Architektur gezeigt, da sie noch eine nicht mehr vorgesehene Altsystemkopplung enthält.

Die Bearbeitung erfolgte mit dem integrierten Bildwerkzeug. Der [abschließende Bearbeitungsauftrag](../assets/connector-framework/image-edit-prompt.txt) ist zusammen mit dem Bild archiviert. Der Diagrammtext und das Handbuch begrenzen die Aussage der Illustration; sie sind kein Nachweis einer bereits implementierten Funktion.
