# Entwicklerhandbuch

Dieses Dokument beschreibt die Zielarchitektur des **FLEET Mira Expansion Package Frameworks**. Es dient als Grundlage für Implementierungsplanung, Schnittstellenverträge und Abnahme. Ein Package soll externe Systeme und kundenspezifische Prozesse anbinden, ohne eine eigene kundenspezifische Kopie des Mira-Produkts zu erzeugen.

!!! info "Entwurfsstatus"
    Version der Web-Ausgabe: **1.0 vom 17.09.2026**. Beschriebene Klassen, Manifeste, Tabellen und Permissions sind Vertragsentwürfe. Ihre Nennung bedeutet nicht, dass sie schon im Produkt implementiert sind. Bestehende Dienste sollen wiederverwendet und fehlende Erweiterungspunkte gezielt ergänzt werden.

## Architekturentscheidungen

| Bereich | Festlegung |
|---|---|
| Produktbasis | Gemeinsame Codebasis; Custom ist eine Erweiterungs- und Leistungsvariante, kein eigener Core-Fork |
| Benutzeroberfläche | PySide6-Erweiterungen innerhalb der Mira-Navigation |
| Hintergrundarbeit | Ein gemeinsamer Handler in `WorkerRuntime`; Enterprise führt ihn über `FleetMiraWorker` aus |
| Connectoren | Versionierte, isolierte Prozesse unter Kontrolle des Workers; zunächst kein weiterer Windows-Dienst |
| Fachzugriffe auf Mira | Integration Gateway, Domain Services und Repositories |
| Externe Zugriffe | Ausschließlich freigegebene API-/Datei-/SQL-Adapter des Pakets |
| Datenhaltung | Core-, Framework- und Paketdaten logisch getrennt; keine anbieterspezifischen Felder im Core |
| Querschnittsfunktionen | Bestehende Jobs, Rechte, Audit und Secret-Verwaltung wiederverwenden |

## Bestand und neue Erweiterungspunkte

Vorhandene Bezugspunkte sind `worker_runtime.py`, `worker_coordination.py`, `database_runtime.py`, `user_management.py`, `global_audit.py`, `administration_ui.py` und `ui_jobs.py`. Die bestehenden Telematikadapter liefern Anhaltspunkte für Anbindung und Betrieb. Ihre aktuelle Implementierung ersetzt noch kein generisches Expansion Framework.

Neu benötigt werden eine geprüfte Paketregistrierung, ein Manifestvertrag, ein Manager für Connectorprozesse, eine Gateway-Schnittstelle und definierte UI-Erweiterungspunkte. Ein zweites konkurrierendes Queue-, Rollen- oder Auditsystem ist nicht vorgesehen. Bestehende Import- und Retry-Verfahren werden vor Wiederverwendung auf ihre jeweiligen Garantien geprüft.

## Logische Schichten und Prozessgrenzen

```mermaid
flowchart TB
    subgraph Client["Enterprise Client"]
        UI["Core UI und Package UI"]
        S["Mira Services<br/>Rechteprüfung und Auftragsanlage"]
        UI -->|"Benutzeraktion"| S
    end
    subgraph Server["Server und Worker"]
        Q[("Framework-Aufträge und Status")]
        W["FleetMiraWorker<br/>WorkerRuntime und Expansion Manager"]
        G["Integration Gateway<br/>Domain Services und Repositories"]
        D[("Mira-Core- und Paketdaten")]
        Q -->|"Lease und Auftrag"| W
        W -->|"validiertes Ergebnis"| G
        G -->|"Transaktion"| D
        W -->|"Fortschritt und Ergebnisstatus"| Q
    end
    subgraph Package["Separater Connectorprozess"]
        C["Backend Connector<br/>Adapter und Mapping"]
    end
    E["Externes System"]
    S -->|"geprüften Auftrag speichern"| Q
    Q -->|"Status lesen"| S
    W -->|"Job über versioniertes Protokoll"| C
    C -->|"Ergebnis oder DTO"| W
    C -->|"API oder freigegebenes SQL"| E
    E -->|"Antwort"| C
```

Der Begriff **Core** bezeichnet gemeinsam verwendete Bibliotheken und fachliche Dienste. Er setzt keinen zusätzlichen zentralen HTTP-Server voraus. Der Enterprise Client kann über vorhandene Mira-Repositories Aufträge in PostgreSQL ablegen. Zentrale Hintergrundeffekte laufen ausschließlich im Worker. Die UI erhält keine Zugangsdaten für externe Systeme.

Die UI Extension läuft im Clientprozess; nur der Backend Connector liegt außerhalb des Workerprozesses. Prozessisolation allein ist keine Sicherheits-Sandbox. Ein signiertes und freigegebenes Paket bleibt vertrauenswürdiger ausführbarer Code und benötigt einen begrenzten Betriebsaccount.

## Aufbau eines Expansion Packages

```text
expansion-example/
  manifest.json
  backend/          Connector, Transport, Mapping, DTOs
  ui/               Navigation, Einstellungen, Zuordnungen, Status
  database/         Versionierte Migrationen für Paketdaten
  workflows/        Auftragsdefinitionen und fachliche Regeln
  permissions/      Rechtebezeichnungen und Übersetzungen
  reports/          Optionale Auswertungen
  schemas/          JSON-Schemas und Beispieldaten
  tests/            Vertrags-, Mapping- und Integrationstests
```

Ein Paket muss nur die tatsächlich benötigten Bestandteile enthalten. Ein kundenspezifisches Paket kann von einem Standardpaket abhängen und zusätzliche Regeln oder Oberflächen bereitstellen. Kundenregeln werden dabei nicht als Sonderfälle in den Standardconnector eingebaut.

## Manifest und Registrierung

Das folgende Manifest ist ein Entwurf und kein aktuell ausführbares Installationsformat:

```json
{
  "id": "example-sap",
  "version": "0.1.0",
  "vendor": "eh-systemhaus e.K.",
  "expansion_api": "1",
  "core_compatibility": ">=1.0,<2.0",
  "backend": {"entrypoint": "backend/connector.exe", "protocol": "1"},
  "ui": {"entrypoint": "ui.extension:register"},
  "capabilities": ["vehicle.pull", "invoice.push"],
  "permissions": ["example.view", "example.configure", "example.execute"],
  "database": {"namespace": "integration_example", "version": 1},
  "dependencies": []
}
```

Die Versionsgrenzen sind Beispielwerte. Die Implementierung definiert verbindliche Bereiche für Core, SDK, Protokoll, UI und Schema. Bei der Installation werden Paket-ID, Herkunft, Signatur, Prüfsummen, Abhängigkeiten und Pfade geprüft. Pfade müssen innerhalb des freigegebenen Paketverzeichnisses bleiben; aus einem Manifest entstehen keine frei zusammengesetzten Shellbefehle.

Die Registry hält installierte und aktivierte Version, Kompatibilitätsstatus, Schema-Version, Capabilities und Fehlerzustand. Installation, Aktivierung und Berechtigung sind getrennte Zustände. Ein inkompatibles Paket wird angezeigt, aber nicht geladen. Es gibt jeweils eine aktive Version pro Paket und definierter Installation beziehungsweise Mandant.

## UI Integration

Eine UI Extension registriert Navigationseinträge, Workspace-Factories und Aktionen über eine begrenzte Host-Schnittstelle. Sie erhält Kontext, Rechteprüfung, Übersetzung, regionale Formatierung und Servicezugriff vom Host. Ein mögliches Interface umfasst `navigation_items()`, `create_workspace(page_id, context)` und `register_actions()`.

Die Einbindung folgt den vorhandenen Administrations- und Arbeitsbereichsmustern:

- Nicht auswählbare Navigationsgruppe, auswählbarer Arbeitsbereich, höchstens eine lokale Unterregisterebene.
- Such- und Filterbereich, gemeinsame Aktionsleiste, Datentabelle und Statusbereich für Listen.
- Eigene Detail-Arbeitsregister für umfangreiche Datensatzbearbeitung; erneutes Öffnen fokussiert denselben Datensatz.
- Stabile technische Widget-IDs und leere Arbeitsregister beim Sitzungsstart.
- Rechteprüfung im UI **und** im aufgerufenen Dienst; ausgeblendete Schaltflächen sind keine Autorisierung.
- Netzwerk- und Datenbankarbeit außerhalb des Qt-Hauptthreads.
- Alle sichtbaren Texte in den 23 unterstützten Anwendungssprachen; Dokumentation mindestens Deutsch/Englisch.

Für Enterprise/Custom kann die Navigation beispielsweise „Administration → Integrationen → SAP“ anbieten. Konfiguration, Zuordnungen, Aufträge und Protokoll werden als passende Arbeitsbereiche oder eine einzelne Ebene lokaler Register gestaltet. Eine zusätzliche tiefe Navigationshierarchie ist nicht erforderlich.

## Worker und Prozessprotokoll

Der Expansion Manager übernimmt Erkennen, Kompatibilitätsprüfung, Aktivierung und Zustandsverwaltung. Ein darunter liegender Connectorprozess-Host startet freigegebene Programme, begrenzt Laufzeit und Ausgaben und beendet hängende Prozesse. Die Verantwortung für Zeitplan, Retry und Jobs verbleibt in der gemeinsamen Worker-Laufzeit.

Für Version 1 ist ein versioniertes, eingerahmtes JSON-/NDJSON-Protokoll über Standard-Ein-/Ausgabe zu prüfen. `stdout` enthält ausschließlich Protokollnachrichten; technische Diagnosen laufen begrenzt und bereinigt über einen eigenen Kanal. Eine Nachricht enthält Protokollversion, Paket, Aktion, Job-ID und Korrelations-ID. Große Datenmengen werden in begrenzten Batches übertragen. Spooldateien sind nur bei tatsächlichem Bedarf mit ACL, Größe, Prüfsumme und Löschfrist zulässig.

```json
{
  "protocol": 1,
  "job_id": "example-job",
  "correlation_id": "example-correlation",
  "package": "example-sap",
  "action": "vehicle.pull",
  "checkpoint": null
}
```

Ein Ergebnis unterscheidet `succeeded`, `retryable_error`, `validation_error` und `outcome_unknown`. Fehler enthalten stabile Codes und bereinigte Meldungen, keine Zugangsdaten. Unterprozessabbruch, unvollständige Antwort und verlorene Verbindung nach einer möglichen Anlage dürfen nicht als sicher erfolgloser Schreibversuch interpretiert werden.

## Datenverträge und Integration Gateway

Adapter übersetzen externe Formate in kleine, versionierte DTOs, beispielsweise Fahrzeug, Person, Kostenstelle oder freigegebene Rechnungsposition. Fachliche Identität, Quellmandant, externe ID, Datumssemantik, Pflichtfelder und Löschsemantik sind ausdrücklich definiert. Fehlend, leer und `null` sind nicht automatisch gleichbedeutend.

```mermaid
flowchart TB
    A["Externe Antwort"] --> B["Connector Mapping"]
    B --> C["Versioniertes DTO"]
    C --> D["Integration Gateway"]
    D --> E["Validierung und Berechtigung"]
    E --> F["Domain Service"]
    F --> G["Repository und Transaktion"]
    G --> H["Mira Fachdaten und Audit"]
```

**Connectoren schreiben niemals direkt in Mira-Core-Fachtabellen.** Das Gateway legt außerdem fest, welche Objekte ein Paket lesen darf. Ein SQL-Connector für ein externes System ist hiervon zu unterscheiden: Er darf dort die ausdrücklich vereinbarten, parametrisierten SQL-Operationen ausführen.

## Datenhaltung und Zuständigkeit

| Bereich | Verantwortung | Beispiele |
|---|---|---|
| Mira Core | Mira-Repositories und Fachlogik | Fahrzeuge, Personen, Kosten und Belege |
| Framework | Host-Repositories | Paketversionen, technische Objektzuordnungen, Checkpoints, Aufträge und Laufstatus |
| Paketdaten | Registrierte Paket-Repositories und Migrationen | Fachlich benötigte Konten- oder Workflowzuordnungen |
| Externes System | Expliziter Backendadapter | API-Aufrufe oder freigegebenes SQL |

Für Enterprise ist eine logische Trennung in `public`, `integration` und `integration_<paket>` beziehungsweise `custom_<kunde>` vorgesehen. **Die Namen sind ein Schemaentwurf.** Die tatsächliche Migration muss zur bestehenden Datenbankabstraktion passen. Neue gemeinsame Repositoryfunktionen dürfen weder PostgreSQL-spezifische Verzweigungen in Fachcode noch direkte `sqlite3`-Verbindungen erhalten. Betroffene gemeinsame Funktionen müssen für SQLite und PostgreSQL dasselbe Ergebnis liefern.

Standardmäßig verwaltet der Host auch Paketdaten über registrierte Repositories. Ein direkter Datenbankzugriff des isolierten Connectors ist nicht erforderlich und wird nicht pauschal freigegeben. Benötigte Zuordnungen werden dem Job kontrolliert übergeben.

Technische Objektzuordnungen sind mindestens nach Umgebung, Installation/Mandant, externem Zugang, Paket, Objekttyp und externer ID eindeutig. Ein vollständiger Nutzdaten-Spiegel gehört nicht automatisch zum Framework. Aufbewahrung, personenbezogene Inhalte und notwendige Prüfstände werden je Paket festgelegt.

## Ausgehende Verarbeitung

```mermaid
sequenceDiagram
    participant U as Benutzer
    participant M as Mira Service
    participant DB as Mira Datenbank
    participant W as FleetMiraWorker
    participant C as Connector
    participant X as Externes System
    U->>M: Vorgang freigeben
    M->>DB: Fachänderung und Outbox in einer Transaktion
    DB-->>M: Commit
    W->>DB: Auftrag mit Lease übernehmen
    W->>C: Job und Idempotenzschlüssel
    C->>X: Externe Operation
    X-->>C: Bestätigung und externe ID
    C-->>W: Ergebnis
    W->>DB: Zuordnung, Status und Audit bestätigen
```

HTTP-Aufrufe laufen außerhalb der Fachtransaktion. Der Worker muss mit Zustellung mindestens einmal rechnen. Wenn das Ziel Idempotenzschlüssel unterstützt, wird derselbe Schlüssel für denselben fachlichen Auftrag wiederverwendet. Sonst wird das Ergebnis vor einer Wiederholung abgeglichen. Bei unklarem Anlageausgang bleibt der Auftrag zur Prüfung stehen. Ein lokaler Commit und ein externer HTTP-Effekt sind keine gemeinsame atomare Transaktion.

## Eingehende Verarbeitung und Konflikte

Der Connector liest alle relevanten Ergebnisseiten, validiert den Datenvertrag und liefert DTOs. Der Host löst technische Identitäten auf und übernimmt freigegebene Felder in einer Transaktion. Ein Checkpoint wird erst nach vollständigem Abruf und dem definierten sicheren Verarbeitungsstand fortgeschrieben. Abrufvollständigkeit und fachliche Übernahme werden getrennt ausgewiesen.

Änderungsfilter sind nur zulässig, wenn sie auch spätere Änderungen alter Datensätze erfassen. Andernfalls ist ein vollständiger periodischer Abgleich erforderlich. Kennzeichen, Datum oder Beschreibung allein rechtfertigen keine automatische Zusammenführung. Eine vorhandene externe ID und eine explizite Zuordnung haben Vorrang; mehrdeutige Treffer gehen in die Prüfliste.

Die Feldführerschaft wird pro Feld festgelegt. Lokal geänderte Importfelder werden gegen den letzten bestätigten Schreibstand geprüft. Ein Konflikt muss sichtbar bleiben und darf nicht durch stilles Überschreiben verschwinden.

## Rechte, Secrets und Audit

Paketrechte werden in die vorhandene Rollenverwaltung aufgenommen, zum Beispiel Anzeigen, Konfigurieren, Zuordnen, Ausführen und Freigeben. Der Worker prüft Paketaktivierung, Aktion und Auftragsursprung erneut. Externe Verbindungen, Secrets und Zielsystemzugänge liegen auf der Worker-Seite; Clientkonfigurationen enthalten nur Referenzen.

Audit-Einträge verbinden Benutzer oder Systemakteur, Paketversion, Aktion, Objekt, Ergebnis und Korrelations-ID. Tokens, Kennwörter und vollständige personenbezogene Payloads gehören nicht ins technische Protokoll. Paketinstallation, Migration, Rechteänderungen und manuelle Konfliktentscheidungen sind ebenfalls nachvollziehbar.

Ein zentraler Statusbereich zeigt letzten erfolgreichen Lauf, ältesten offenen Auftrag, ausstehende Prüffälle und Datenstand. Wiederholungen verwenden begrenzten Backoff und gegebenenfalls `Retry-After`. Datenfehler und fehlende fachliche Zuordnungen erfordern Korrektur statt endloser automatischer Wiederholung.

## SAP als Paketbeispiel

Ein SAP-Paket kann Verbindung, Konten-/Kostenstellenzuordnung, Freigabe, Exportstatus und Berichte umfassen. Eine Kostenart wird über gültige Regeln auf Buchungskreis, Sachkonto, Steuerkennzeichen und gegebenenfalls Profit Center abgebildet. Das ist eine fachliche Zuordnung mit Gültigkeitszeitraum und Prüfstatus, keine unkontrollierte Textkonvertierung.

```mermaid
flowchart TB
    A["Rechnung prüfen"] --> B["Fahrzeug und Kostenart zuordnen"]
    B --> C["SAP Kontierung prüfen"]
    C --> D["Freigabe"]
    D --> E["Outbox"]
    E --> F["Worker und SAP Connector"]
    F --> G["SAP Bestätigung"]
```

SAP ist hier ein Beispiel für die Paketarchitektur, keine Aussage über einen bereits verfügbaren Connector oder eine bestimmte SAP-API.

## Externe Systeme und Telematik

FLEET Mira ist das Nachfolgeprodukt. Das Framework dient der Erweiterung von Mira und der Anbindung externer Fachsysteme; eine dauerhafte Synchronisation mit dem bisherigen Fuhrparksystem ist nicht vorgesehen. Eine gegebenenfalls erforderliche einmalige Migration gehört in ein gesondertes Übernahmeprojekt.

```mermaid
flowchart TB
    UI["Mira Package UI"] -->|"geprüfter Auftrag"| Q["Mira Auftragsablage"]
    Q -->|"Lease und Job"| W["FleetMiraWorker"]
    W -->|"Job"| P["Backend Connector"]
    P -->|"freigegebene API / SQL"| E["Externes System oder Telematik"]
    E -->|"Antwort"| P
    P -->|"DTO und technischer Status"| W
    W -->|"Validieren und übernehmen"| G["Mira Integration Gateway"]
    G -->|"Fachlogik und Repository"| D[("Mira Fachdaten")]
```

Jedes konkrete Paket benötigt einen bestätigten Schnittstellenvertrag mit Zugangsverfahren, Pflichtfeldern, Datumssemantik, Seitennavigation und Aktualisierungsverhalten. Die Wahl zwischen API, Datei und direktem SQL betrifft das externe Zielsystem, nicht einen Umgehungsweg in Mira-Core-Tabellen.

Es gelten folgende Leitplanken:

- Nur ausdrücklich vereinbarte, fachlich passende Datenfelder abgleichen. Zusätzliche Anbieterinformationen nicht automatisch als neue Core-Felder übernehmen.
- Neue Datensätze sind bei geklärter Identität, passenden Pflichtfeldern und bestätigter Zuständigkeit möglich.
- Technische Zuordnungen, Prüfsummen und Fehler getrennt von Fachdaten führen. Nutzdaten nicht ohne begründeten Paketvertrag dauerhaft spiegeln.
- Datenführerschaft und lokale Bearbeitung pro Feld festlegen. Externe Statuswerte dürfen lokale Abschlüsse nicht ungeprüft auslösen.
- Zeitpläne und Datenstand pro System konfigurieren. Ohne zuverlässigen Änderungsfilter auch Änderungen älterer Datensätze durch vollständigen Abgleich erfassen.
- Schreiboperationen gegen externe Systeme benötigen eindeutige Wiederholungs- und Abgleichregeln. Unklare Anlageausgänge werden vor erneutem Schreiben geklärt.
- Ein SQL-Adapter arbeitet mit festen freigegebenen Tabellen-/Spaltennamen, gebundenen Parametern, begrenzten Rechten und lokalen Transaktionen.
- HTTP-Effekt, externe SQL-Transaktion und Mira-Transaktion sind nicht automatisch atomar. Fehlergrenzen und Wiederanlauf gehören zum Paketvertrag.

Die Umsetzung verwendet die bestehenden Mira-Hostfunktionen für Bedienung, Zeitplanung, Aufträge und Überwachung. Ein weiterer eigenständiger Scheduler oder Windows-Dienst ist nicht vorgesehen.

## Versionierung, Installation und Wiederherstellung

Core, Expansion API, Paket, UI und Schema erhalten getrennte Versionen. Ein Paket wird zunächst geprüft und in ein versioniertes Verzeichnis installiert, danach kontrolliert migriert und aktiviert. Laufende Jobs werden vor einem Wechsel beendet oder an einem bestätigten Checkpoint angehalten. Neue Jobs starten erst mit konsistentem Backend-/UI-/Schemasatz.

```mermaid
flowchart TB
    A["Paket installieren"] --> B["Signatur und Kompatibilität prüfen"]
    B --> C["Backup und Migration prüfen"]
    C --> D["Migration ausführen"]
    D --> E["Aktivieren und Smoke-Test"]
    E --> F["Überwachen"]
    F --> G["Update vorbereiten"]
    G --> B
    E -->|"Fehler"| R["Deaktivieren und geprüften Restore anwenden"]
```

Ein Austausch der EXE ist nach einer inkompatiblen Datenmigration kein ausreichender Rollback. Rückkehr setzt rückwärtskompatibles Schema oder ein geprüftes Backup-/Restore-Verfahren voraus. Programmdateien sind schreibgeschützt; veränderliche Konfiguration und Zustand liegen getrennt. UI-Bundles werden nur aus geprüften Paketen geladen, nicht aus beliebigen benutzerbeschreibbaren Python-Pfaden.

## Repositorystrategie und CI/CD

Der Mira-Core behält Hostintegration und gemeinsame Fachlogik. Ein separates Expansion-Repository kann SDK, Protokoll, Schemas, Testkit und Standardpakete bündeln. Kundenpakete können eigene private Repositories erhalten. Eine Trennung ist erst dann sinnvoll, wenn Versionierung und Vertragsprüfungen reproduzierbar funktionieren; neue Repositories sind mit diesem Dokument noch nicht angelegt.

Die Pipeline prüft Manifest, Abhängigkeiten, Paketgrenzen, Unit-/Vertragstests, Migrationen, UI-Kompatibilität und Secretfreiheit. Sie baut versionierte Artefakte, erzeugt Prüfsummen, signiert freizugebende Windows-Komponenten und testet Installation, Update und Wiederherstellung. Eine Freigabe referenziert getestete Versionen von Core, SDK, Schema und Paket.

## Umsetzung und Abnahme

1. Bestandsarchitektur und verbindliche Paketverträge prüfen; Enterprise-Pilot und Feldführerschaft festlegen.
2. Minimale Registry und Paketprüfung implementieren; ein Testpaket ohne externe Schreibeffekte integrieren.
3. Gemeinsamen Worker-Handler, Prozessprotokoll, Leases und Fehlerklassen ergänzen.
4. Gateway und technische Zuordnungen mit Transaktions-/Konfliktprüfung implementieren.
5. UI-Extension über vorhandene Navigation, Rechte und Übersetzungen anbinden.
6. Erstes Paket für ein externes System mit bestätigtem Vertrag und isolierter Testumgebung integrieren.
7. Pilot, Wiederanlauf, Update und Restore nachweisen; erst danach produktiv freigeben.

| Abnahme | Erwartung |
|---|---|
| Inkompatibles oder verändertes Paket | Keine Aktivierung; verständlicher Fehlerstatus |
| Fehlende Berechtigung | Aktion auch serverseitig abgewiesen |
| Wiederholter Auftrag | Keine zusätzliche externe oder lokale Anlage |
| Zwei Worker | Exklusive Lease; verlorener Besitzer schreibt nicht weiter |
| Absturz nach möglichem Commit | Unklarer Ausgang bleibt gesperrt und wird abgeglichen |
| Lokale Feldänderung | Konflikt sichtbar; kein stiller Datenverlust |
| API-Limit oder abgelaufenes Token | Begrenzte Wiederaufnahme ohne Geheimnisse im Log |
| Versionswechsel | Geprüfte Kombination; nachvollziehbare Migration und Restore |
| UI und Sprachen | Gleiche Navigationsregeln, stabile IDs, vollständige Übersetzung |
| Gemeinsame Datenbankfunktion | Gleiche fachliche Ergebnisse mit SQLite und PostgreSQL |

Dieses Dokument erweitert die Dokumentation, nicht den Lieferumfang der Anwendung. Die allgemeinen Architekturregeln und die [Grafikprüfung](diagram-review.md) bleiben bei der Umsetzung maßgeblich.
