# Connector Framework

Das **FLEET Mira Expansion Package Framework** ist das Zielkonzept für kundenspezifische Module, Schnittstellen und Workflows auf Basis von FLEET Mira. Ein Expansion Package bündelt die benötigten Connectoren, integrierten Oberflächen, Zuordnungsregeln und Berechtigungen.

!!! info "Konzept und Entwicklungsgrundlage"
    Stand: **17. September 2026**. Die folgenden Seiten beschreiben eine geplante Erweiterungsarchitektur, keine bereits ausgelieferte Framework-Funktion. Der gemeinsame Anwendungskern und die Worker-Laufzeit existieren; Paketregistrierung, Erweiterungsprotokoll und Integration Gateway sind noch zu implementieren und abzunehmen.

## Die drei Konzeptdokumente

| Dokument | Zielgruppe | Inhalt |
|---|---|---|
| [Entwicklerhandbuch](developer-handbook.md) | Entwicklung und Integration | Architektur, Erweiterungspunkte, Datenverträge, Prozesse, Sicherheit, Tests und Deployment mit Mermaid-Diagrammen |
| [Produktbeschreibung](customer-concept.md) | Kunden und Projektverantwortliche | Nutzen, Bestandteile, Beispielprozesse, Einführung und Leistungsabgrenzung |
| [Produktflyer](product-flyer.md) | Erstgespräch und Überblick | Kompakte grafische Zusammenfassung des Gesamtkonzepts |

[Grafikprüfung und verbindliche Pfeilbedeutung](diagram-review.md) erläutert die Korrekturen an der bereitgestellten Übersichtsgrafik. Die dortigen gerichteten Diagramme präzisieren die vereinfachte Illustration.

[Web-Ausgabe herunterladen](../assets/connector-framework/concept-documents.zip){ .md-button }

Das ZIP enthält die deutsche und englische Markdown-Fassung einschließlich Grafiken und Mermaid-Quelltexten. Es enthält keine ursprünglichen Word-Dateien.

## Aufbau auf einen Blick

```mermaid
flowchart TB
    U["Mira Client<br/>Core UI und UI Extensions"] -->|"Aktion über Mira Services"| Q["Auftragsablage"]
    Q -->|"Auftrag übernehmen"| W["FleetMiraWorker"]
    W -->|"Job"| C["Backend Connector<br/>isolierter Prozess"]
    C -->|"API oder SQL"| E["Externes System"]
    E -->|"Antwort"| C
    C -->|"Ergebnis oder DTO"| W
    W -->|"Validieren und übernehmen"| G["Integration Gateway<br/>Domain Services und Repositories"]
    G -->|"geprüfte Änderungen"| D[("Mira Fachdaten")]
```

**Leseregel:** Ein Pfeil zeigt eine benannte Operation oder Datenübergabe. Der Core ist eine logische Softwareschicht, kein zusätzlicher vorgeschriebener Serverdienst. Externe Connectoren schreiben nicht direkt in Mira-Core-Tabellen.

## Einordnung der Dokumente

Die Web-Ausgabe überführt die verfügbaren Inhalte des im August 2026 erarbeiteten Konzepts „FLEET Mira Custom“ und die bereitgestellte Grafik in versionierbare Markdown-Dokumente. Die ursprünglichen drei Word-Dateien standen für diese Übernahme nicht zur Verfügung; diese Seiten sind daher eine **redaktionell überarbeitete Web-Ausgabe**, keine unveränderten DOCX-Originale. Die deutsche und englische Fassung werden gemeinsam gepflegt.

Die überarbeitete Architektur berücksichtigt die vorhandene gemeinsame Produktlaufzeit. Insbesondere bleiben Basic und Pro bei SQLite mit integriertem Worker, während Enterprise PostgreSQL und den separaten `FleetMiraWorker` verwendet. Das Expansion-Konzept startet bei Enterprise/Custom; eine Freigabe für weitere Editionen erfordert deren gesonderte Einordnung und Tests.

FLEET Mira ist als Nachfolgeprodukt vorgesehen. Eine dauerhafte Anbindung an das bisherige Fuhrparksystem gehört nicht zum Zielbild. Beispiele verwenden allgemeine Kategorien wie **Externes System**, **ERP/Buchhaltung** und **Telematik**. Eine gegebenenfalls benötigte einmalige Datenmigration wäre ein gesondertes Vorhaben und kein laufender Connector.
